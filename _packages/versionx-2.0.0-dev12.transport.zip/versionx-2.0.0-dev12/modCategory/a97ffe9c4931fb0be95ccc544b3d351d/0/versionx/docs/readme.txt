--------------------
VersionX
--------------------
Version: 2.0.0
Author: Mark Hamstra <hello@markhamstra.com>
--------------------

VersionX is a utility tool for MODX Revolution that will help you keep track of your content in Resources, Templates,
Chunks, Snippets and Plugins. Every save is recorded and can easily be looked back and compared through the component.

NOTE: VersionX 2.0 is a complete rewrite and is NOT compatible with VersionX 1.0.