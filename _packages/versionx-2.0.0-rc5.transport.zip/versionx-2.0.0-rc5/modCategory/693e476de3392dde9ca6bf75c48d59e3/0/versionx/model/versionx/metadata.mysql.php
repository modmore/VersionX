<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'vxResource',
    1 => 'vxTemplate',
    2 => 'vxChunk',
    3 => 'vxSnippet',
    4 => 'vxPlugin',
    5 => 'vxTemplateVar',
  ),
);