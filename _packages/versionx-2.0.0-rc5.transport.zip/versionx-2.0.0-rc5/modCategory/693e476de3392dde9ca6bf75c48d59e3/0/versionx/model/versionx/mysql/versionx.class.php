<?php
require_once (dirname(dirname(__FILE__)) . '/versionx.class.php');
class Versionx_mysql extends Versionx {}