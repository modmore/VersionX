<?php
require_once dirname(__DIR__) . '/revert.class.php';

class VersionXTemplatesRevertProcessor extends VersionXRevertProcessor {
    public $classKey = 'vxTemplate';
}

return 'VersionXTemplatesRevertProcessor';

